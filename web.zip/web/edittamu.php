
<?
include "koneksi.php";
?>
<div id="tengah">
       <td>
       <span>
      <div class="judulpage">Edit Data tamu</div>
	   <? 
	   	$id_tamu= $_GET['id_tamu'];
		$cmd1 = mysql_query("SELECT * FROM tamu WHERE id_Fasilitas='$id_tamu'");
		$data = mysql_fetch_array($cmd1);
	   ?>
       <form action="<? echo $_SERVER['PHP_SELF'];?>"method="post">
	   
     <table width="75%" border="0" align="center">
    <tr> 
      <td width="49%"><div align="center">ID TAMU</div></td>
      <td width="4%"><div align="center"><strong>:</strong></div></td>
        <td width="47%"><input type="text" name="id_tamu"  size="30"  value="<? echo $data['id_tamu'];?>" readonly/></td>
    </tr>
    <tr> 
      <td><div align="center">NIK</div></td>
      <td><div align="center"><strong>:</strong></div></td>
        <td><input type="text" name="nik"  size="30"  value="<? echo $data['nik'];?>"></td>
    </tr>
    <tr> 
      <td colspan="3"><div align="center"> 
            <input type="submit" name="submit" id="submit2" value="Simpan" class="submit">
          </div></td>
    </tr>
  </table>
</form>

<?
       if($_POST['submit']){
       $id_tamu = $_POST['id_tamu'];
       $nik = $_POST['nik];
	   $nama = $_POST['nama'];
	   $alamat = $_POST['alamat'];
	   
            
       $cmd = mysql_query("UPDATE tamu SET id_tamu='$id_tamu',nik='$nik' WHERE id_tamu='$id_tamu'")or die(mysql_error());
      {
       ?>
       <script>
       alert('Data Berhasil Di Ubah');
       window.location="master.php";
       </script>
       <?
       }
       }
       ?>