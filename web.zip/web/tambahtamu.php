<?
include "koneksi.php";
$query = mysql_query("SELECT * FROM tamu ORDER BY id_tamu DESC");
$datapage = mysql_fetch_array($query);
$no = $datapage['id_tamu'] + 1;


?>



<div class="judulpage">Tambah Data tamu</div>
       <form action="<?echo $_SERVER['PHP_SELF'];?>" method="post">
       <table cellpadding="4" cellspacing="1">
       <tr>
          
      <td> <span> Id tamu: </span> </td>
       <td>
       <input type="text" name="id_tamu" size="30" class="textfield"  value="<?echo $no;?>">
       </td>
       </tr>
	   <tr>
          <td> <span> Nik : </span> </td>
       <td>
       <input type="text" name="nik"  size="30" class="textfield">
       </td>
       </tr>
       <tr>
          <td> <span> Nama : </span> </td>
       <td>
       <input type="text" name="nama"  size="30" class="textfield">
       </td>
       </tr>
	   <tr>
          <td> <span> Alamat : </span> </td>
       <td>
       <input type="text" name="alamat"  size="30" class="textfield">
       </td>
       </tr>
	    
       <td>
       <input type="submit" name="submit" id="submit" value="Simpan" class="submit">
       </td>
	  
       </tr>
       </table>
        </form>
      
       
       <?
       if($_POST['submit']){
       $id_tamu = $_POST['id_tamu'];
       $nik = $_POST['nik'];
	   $nama_tamu = $_POST['nama'];
	   $alamat = $_POST['alamat'];
      
	         


if (trim($id_tamu)=="") {?>
		<script>
		alert('Data masih kosong!Periksa kembali.');
		history.go(-1);
		</script>
<?php
}
elseif (trim($nik)=="") {?>
		<script>
		alert('Data masih kosong!Periksa kembali.');
		history.go(-1);
		</script>
<?php

}

	   else{
$sql = mysql_query("INSERT INTO tamu VALUES ('$id_tamu','$nik','$nama_tamu','$alamat')" )or die(mysql_error());
       
          ?>
       <script>
       alert('Data Berhasil ditambahkan ke Database');
       window.location="master.php";
       </script>
       <?
     }
       }
      
       ?>
