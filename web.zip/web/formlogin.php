<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
</head><body>
<div align="center">
  <form action="login.php" method="post" >
    <table align="center"  border="1" width="54%">
      <tbody>
        <tr> 
          <td rowspan="2" align="center" valign="middle" width="32%"> <div align="center"><img src="IMAGE/Lock.png"
width="98" height="98"></div></td>
          <td width="68%" height="32"> <div align="left"> 
              <p><font color="#ff6600" face="Monotype Corsiva" size="5"><strong>LOGIN 
               </strong></font></p>
            </div></td>
        </tr>
        <tr> 
          <td height="148"> <table align="center" border="0" width="70%">
              <tbody>
                <tr> 
                  <td><strong><font face="Arial, Helvetica, sans-serif" 
size="2">Username</font></strong></td>
                </tr>
                <tr> 
                  <td><strong><font face="Arial, Helvetica, sans-serif"> 
                    <input name="username" size="25" 
type="text">
                    </font></strong></td>
                </tr>
                <tr> 
                  <td><strong><font face="Arial, Helvetica, sans-serif" 
size="2">Password</font></strong></td>
                </tr>
                <tr> 
                  <td><input name="password" size="25" type="password"></td>
                </tr>
                <tr> 
                  <td align="left" valign="middle"> <input name="Submit2" value="Login" type="submit"> 
                  </td>
                </tr>
              </tbody>
            </table></td>
        </tr>
      </tbody>
    </table>
    <p>&nbsp;</p>
    </form>
  
</div>
</body></html>