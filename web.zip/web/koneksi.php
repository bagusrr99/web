<?php
$host="localhost";
$userdb="root";
$passdb="123456789";
$namadb="karlita";

$conect=mysql_connect($host,$userdb,$passdb)  or die (mysql_error());
mysql_select_db($namadb,$conect) or die (mysql_error());
?>