<?
include "koneksi.php";
?>
<div id="tengah">
       <td>
       <span>
      <div class="judulpage">Edit Data Fasilitas</div>
	   <? 
	   	$id_fasilitas= $_GET['id_fasilitas'];
		$cmd1 = mysql_query("SELECT * FROM Fasilitas WHERE id_fasilitas='$id_fasilitas'");
		$data = mysql_fetch_array($cmd1);
	   ?>
       <form action="<? echo $_SERVER['PHP_SELF'];?>"method="post">
	   
     <table width="75%" border="0" align="center">
    <tr> 
      <td width="49%"><div align="center">ID FASILITAS</div></td>
      <td width="4%"><div align="center"><strong>:</strong></div></td>
        <td width="47%"><input type="text" name="id_fasilitas"  size="30"  
		value="<? echo $data['id_fasilitas'];?>" /></td>
    </tr>
    <tr> 
      <td><div align="center">NAMA FASILITAS YANG TERSEDIA</div></td>
      <td><div align="center"><strong>:</strong></div></td>
        <td><input type="text" name="nama_fasilitas"  size="30"  
		value="<? echo $data['nama_fasilitas'];?>"></td>
    </tr>
    <tr> 
      <td colspan="3"><div align="center"> 
            <input type="submit" name="submit" id="submit2"
			 value="Simpan" class="submit">
          </div></td>
    </tr>
  </table>
</form>

<?
       if($_POST['submit']){
       $id_fasilitas = $_POST['id_fasilitas'];
       $nama_fasilitas = $_POST['nama_fasilitas'];
            
       $cmd = mysql_query("UPDATE fasilitas SET id_fasilitas='$id_fasilitas',
	   nama_fasilitas='$nama_fasilitas' 
	   WHERE id_fasilitas='$id_fasilitas'")or die(mysql_error());
      {
       ?>
       <script>
       alert('Data Berhasil Di Ubah');
       window.location="tampilfasilitas.php";
       </script>
       <?
       }
       }
       ?>