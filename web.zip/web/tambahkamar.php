<?
include "atas.php";
include "conect.php";

$query = mysql_query("SELECT * FROM t_kamar ORDER BY idkamar DESC");
$datapage = mysql_fetch_array($query);
$no = $datapage['idkamar'] + 1; 

$perintah="select fasilitas.* from fasilitas inner join t_kamar on fasilitas.id_fasilitas = t_kamar.idkamar where t_kamar.id_Fasilitas = '$id_Fasilitas'";
$hasil=mysql_query($perintah);
$row=mysql_fetch_array($hasil); 


?>

       <td>
       <span>
       <div class="judulpage">Tambah Data </div>
       <form action="<?echo $_SERVER['PHP_SELF'];?>" method="post">
       <table cellpadding="4" cellspacing="0">
       <tr><td><span>ID kamar	:</span></td>
       <td><input type="text" name="id_kamar" id="id_jur" size="30" class="textfield" value="<?echo $no;?>" readonly=""></td></tr>
       <tr>
       <td>
       <span>
       Type Kamar:
       </span>
       </td>
       <td>
       <input type="text" name="namakamar"  size="30" class="textfield">
       </td>
       </tr>
        <tr>
       <td>
       <span>
       Nama_PTN :
       </span>
       </td>
       <td>
     <select name="kd_Fasilitas">
                <?
                    // Mengambil data kota
                	$sqlstr="select * from Fasilitas order by nama_Fasilitas";
                	$hasil=mysql_query($sqlstr);
                	while($row=mysql_fetch_array($hasil))
                	{
					echo("<option value=\"$row[0]\">$row[1] </option>");
					}
                    
                ?>
              </select>
       </td>
       </tr>
       <td>
       <input type="submit" name="submit" id="submit" value="Simpan" class="submit">
       </td>
	  
       </tr>
       </table>
        </form>
       <?
       if($_POST['submit']){
       $id_kamar = $_POST['id_kamar'];
       $nama_kamar = $_POST['namakamar];
	   $id_Fasilitas = $_POST['id_Fasilitas'];     

if (trim($id_kamar)=="") {?>
		<script>
		alert('Data masih kosong!Periksa kembali.');
		history.go(-1);
		</script>
<?php
}
elseif (trim($namakamar)=="") {?>
		<script>
		alert('Data masih kosong!Periksa kembali.');
		history.go(-1);
		</script>
<?php
}
elseif (trim($id_Fasilitas)=="") {?>
		<script>
		alert('Data masih kosong!Periksa kembali.');
		history.go(-1);
		</script>
<?php
}
	   else{
$sql = mysql_query("INSERT INTO t_kamar VALUES ('$id_kamar','$nama_kamar','$id_Fasilitas')") or die(mysql_error());
       
       ?>
       <script>
       alert('Data Berhasil ditambahkan ke Database');
       window.location="";
       </script>
       <?
     }
       }
      
       ?>