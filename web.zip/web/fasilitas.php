<?php

include "koneksi.php";

$query = mysql_query(" select * from fasilitas order by id_fasilitas desc");
$datapage = mysql_fetch_array($query);
$no = $datapage['id_fasilitas']+1; 
?>



  
<td align="right"><div class="judulpage"> 
    <div align="center">Tambah Data </div>
  </div>

	 <form action="<?echo $_SERVER['PHP_SELF'];?>" method="post">
     <table width="75%" border="0" align="center">
    <tr> 
      <td width="49%"><div align="center">ID FASILITAS</div></td>
      <td width="4%"><div align="center"><strong>:</strong></div></td>
      <td width="47%"><input name="id_fasilitas" type="text" id="id_fasilitas" value="<?echo $no;?>" readonly=""></td>
    </tr>
    <tr> 
      <td><div align="center">NAMA FASILITAS YANG TERSEDIA</div></td>
      <td><div align="center"><strong>:</strong></div></td>
      <td><textarea name="nama_fasilitas" id="nama_fasilitas"></textarea></td>
    </tr>
    <tr> 
      <td colspan="3"><div align="center">
          <input type="submit" name="submit" id="submit" value="Simpan" class="submit">
        </div></td>
    </tr>
  </table>
</form>


		<?
if(isset($_POST['submit'])){
	$id_fasilitas = $_POST['id_fasilitas'];
	$nama_fasilitas = $_POST['nama_fasilitas'];
if(trim($nama_fasilitas)=="") {?>
		<script>
		alert('data masih kosong!periksa ke database');
		history.go(-1);
		</script>
<?php

}
		else{
$sql=mysql_query("insert into fasilitas (id_fasilitas,nama_fasilitas)
values ('$id_fasilitas','$nama_fasilitas')") or die (mysql_error());
?>
	<script>
	alert('data berhasil di tambahkan ke database');
	window.location="tampilfasilitas.php";
	</script>
	
<?

		}
	}

		?>


