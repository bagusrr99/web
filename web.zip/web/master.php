
<?

include "koneksi.php";

$id_fasilitas=$_GET['id_tamu'];?>
<script language="JavaScript">
function Knf()
{
    var z=window.confirm("Benarkah data ini akan anda hapus?");
    if(z==true)
    {
        return true;
    }else
    {
        return false
    }

}
</script>
<?



if($do="hapus"){
$cmd = mysql_query("DELETE FROM tamu WHERE id_tamu ='$id_tamu'");
}
?>
<div id="tengah">
<form action="cari.php" method="post">	
  <td> NAMA 
  <input name="inputcari" type="text" >
  </td> 
  <td> </td>
  <td>
  <input name="search" type="submit" value="search">
   </td>

<form name="form1" method="post" action="Fasilitas.php">
        <input type="submit" name="Submit" value="+Tambah data tamu">
      </form><br>
	  
<table width="75%" border="0">
  <tr> 
    <td width="20%"><div align="center">ID TAMU</div></td>
    <td width="26%"><div align="center">NIK</div></td>
    <td width="28%"><div align="center">NAMA</div></td>
    <td width="28%"><div align="center">ALAMAT</div></td>
    <td colspan="2"><div align="center">ACTION</div>
      <?php
    $batas = 7;
	$hal=$_GET['hal'];
	if(empty($hal))
	{
	$posisi=0;
	$hal=4;
	}
	else
	{
	$posisi=($hal-1)*$batas;
	}
	  $sql_berita = " SELECT * FROM tamu order by id_tamu LIMIT $posisi,$batas";
	  $hsl_berita = mysql_query(" SELECT * FROM tamu order by id_tamu ", $conect);
	  $qry_berita = mysql_query($sql_berita, $conect) or die ("Gagal tampilkan query".mysql_error());
	  $jmldata=mysql_num_rows($hsl_berita);
	  $jmlhal=ceil($jmldata/$batas);
	  $no=$posisi+1;
	  while ($data = mysql_fetch_array($qry_berita)) {
	  $no++;
	  ?>
  <tr> 
    <td><? echo $data['id_tamu'];?><echo $data['id_fasilitas'];?></td>
    <td><? echo $data['id_tamu'];?></td>
    <td><? echo $data['nama_tamu'];?></td>
    <td> <? echo $data['alamat'];?> <echo $data['nama_fasilitas'];?></td>
    <td width="11%"><a href="editkota.php?id_kota=<?php echo $data[id_fasilitas];?>" ><img src="edit.JPG"></td>
    <td width="15%"><a href="tampilfasilitas.php?do=hapus&id_fasilitas=<?php echo $data[id_fasilitas];?>"onClick='return Knf()'><img src="cancel.png"></td>
  </tr>
  <?
      
       }
       
       ?>
  <tr> 
    <td colspan="6">HALAMAN 
      <?php 
    			for($i=1;$i<=$jmlhal;$i++)
				if($i!=hal)
				{
				echo"<a href=$_SERVER[PHP_SELF]?master.php&hal=$i>[ $i ]</a>  ";
				}
				else
				{
				echo"<b>$i</b>";
				}
			?>
    </td>
  </tr>
</table>
