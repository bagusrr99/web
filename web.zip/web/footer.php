<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#00FFFF">

<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="75%" border="0" align="center">
  <tr>
    <td><div align="center"><strong><em>Copyright@ SMK Karya Bhakti Brebes</em></strong></div></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
