<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div align="center">
  <p><strong><em>SELAMAT DATANG DI HOTEL KARLITA </em></strong></p>
  <p>&nbsp;</p>
  <table width="75%" border="1">
    <tr> 
      <td width="21%"><div align="center"><strong><em>HOME</em></strong></div></td>
      <td width="28%"><div align="center"><strong><em><a href="rooms.php">ROOMS</a></em></strong></div></td>
      <td width="24%"><div align="center"><strong><em><a href="contack.php">CONTACK</a></em></strong></div></td>
      <td width="27%"><div align="center"><strong><em><a href="formlogin.php">LOGIN</a></em></strong></div></td>
    </tr>
  </table>
  <p><em><strong></strong></em></p>
</div>
</body>
</html>
