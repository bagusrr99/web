<div align="center">
<table width="50%" border="1" cellspacing="0" cellpadding="0">
  <tr bgcolor="#CCCCCC">
  <td width="2%" height="40"> <div align="center">Nik</div></td>
            <td width="5%"> <div align="center">Nama</div></td>
			<td width="4%"> <div align="center">Alamat</div></td>
					  </tr>

<? 
include "koneksi.php"; 
$no=0;
  		$cari = $_POST['search'];
		$query = "select * from tamu where id_tamu like '%$cari%'";
		$result = mysql_query($query);
		while($data = mysql_fetch_array($result)){
		$no++;
		echo
		<tr>
		 
		  <td> <? echo $data['nik'];?> <div align="center"></td>
		  <td> <? echo $data['nama'];?> <div align="center"></div></td>
		  
		  <td> <? echo $data['alamat'];?> <div align="center"></div></td>
		  <? }}?

 ?>

		  >

</table>

 </div>
 <?
echo "[<a href=javascript:history.back(1);>kembali</a>]";
?>
