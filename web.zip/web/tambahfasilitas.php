<?
include "koneksi.php";

$query = mysql_query("SELECT * FROM Fasilitas ORDER BY Id_Fasilitas DESC");
$datapage = mysql_fetch_array($query);

?>


    
  <td>
<div class="judulpage"> 
    <div align="center"><strong>Tambah Data </strong></div>
  </div>
  <table cellpadding="4" cellspacing="0" border="0">
    <form action="<?echo $_SERVER['PHP_SELF'];?>" method="post">
      <tr> 
        <td width="314"><div align="center">ID FASILITAS</div></td>
        <td width="10"> <div align="center"><span> <strong>:</strong></span> </div></td>
        <td width="189"> <input type="text" name="id_fasilitas"  size="10" class="textfield"> 
        </td>
      </tr>
      <tr> 
        <td><div align="center">FASILITAS YANG TERSEDIA </div></td>
        <td> <div align="center"><span> <strong>:</strong></span> </div></td>
        <td> <textarea name="nama_fasilitas"></textarea> </td>
      </tr>
      <tr> 
        <td colspan="2"> <input type="submit" name="submit" id="submit" value="Simpan" class="submit"> 
        </td>
      </tr>
    </form>
  </table>
  <?
if(isset($_POST['submit'])){
       $id_Fasilitas = $_POST['id_Fasilitas'];
       $nama_Fasilitas = $_POST['nama_Fasilitas'];
if (trim($nama_Fasilitas)=="") {?>
  <script>
		alert('Data masih kosong!Periksa kembali.');
		history.go(-1);
		</script>
<?php

}
	   else{
$sql = mysql_query("INSERT INTO Fasilitas (Id_Fasilitas,nama_Fasilitas)
VALUES ('$id_Fasilitas','$nama_Fasilitas')") or die(mysql_error());
       
       ?>
       <script>
       alert('Data Berhasil ditambahkan ke Database');
       window.location="";
       </script>
  <?
     }
       }
      
       ?>
