
<?php
include "header.php";?>

<table width="67%" border="1" align="center">
  <tr>
    <td width="26%"><img src="Blue%20hills.jpg" width="151" height="50"></td>
    <td width="31%"><img src="Sunset.jpg" width="185" height="50"></td>
    <td width="43%"><img src="Water%20lilies.jpg" width="179" height="50"></td>
  </tr>
  <tr>
    <td height="23"><div align="center">REGULAR</div></td>
    <td><div align="center">VIP</div></td>
    <td><div align="center">PRESDEN SUIT</div></td>
  </tr>
</table>

<p>&nbsp;</p>
<p><a href="index.php">kembali</a></p>
<?php 
include "footer.php";
?>