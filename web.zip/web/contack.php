
<?php 
include "header.php";
?><body bgcolor="#66FF00" text="#FFFFFF"><table width="75%" border="1" align="center">
  <tr>
    <td bgcolor="#FF00FF"><p align="center"><strong>Info lebih lanjut tentang 
        HOTEL KARLITA bisa datang langsung di</strong></p>
      <p align="center"><strong>jl. semrawud no.123 tegal utara</strong></p>
      <p align="center"><strong>No. 0857578965458</strong></p>
      </td>
  </tr>
</table>
<?php
include "footer.php";
?>

<p>&nbsp;</p>
<p><a href="index.php"><strong>kembali</strong></a></p>
