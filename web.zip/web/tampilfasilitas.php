<?php

include "koneksi.php";

$id_fasilitas=$_GET['id_fasilitas'];?>
<script language="JavaScript">
function Knf()
{
    var z=window.confirm("Benarkah data ini akan anda hapus?");
    if(z==true)
    {
        return true;
    }else
    {
        return false
    }

}
</script>
<?



if($do="hapus"){
$cmd = mysql_query("DELETE FROM Fasilitas WHERE id_fasilitas ='$id_fasilitas'");
}
?>
<? $hasil1= mysql_query("SELECT * from fasilitas ");
		$halaman	= mysql_num_rows($hasil1);
		echo "";
	?>

<form name="form1" method="post" action="Fasilitas.php">
        <input type="submit" name="Submit" value="+Tambah data">
      </form><br>
	  
<table width="75%" border="5" id="tablepage">
  <tr> 
    <td width="26%" height="42"><div align="center">ID FASILITAS</div></td>
    <td width="38%"><div align="center">NAMA FASILITAS</div></td>
    <td colspan="2"><div align="center">ACTION</div>

    <?php
    $batas = 7;
	$hal=$_GET['hal'];
	if(empty($hal))
	{
	$posisi=0;
	$hal=4;
	}
	else
	{
	$posisi=($hal-1)*$batas;
	}
	  $sql_berita = " SELECT * FROM Fasilitas order by id_Fasilitas LIMIT $posisi,$batas";
	  $hsl_berita = mysql_query(" SELECT * FROM Fasilitas order by id_Fasilitas ", $conect);
	  $qry_berita = mysql_query($sql_berita, $conect) or die ("Gagal tampilkan query".mysql_error());
	  $jmldata=mysql_num_rows($hsl_berita);
	  $jmlhal=ceil($jmldata/$batas);
	  $no=$posisi+1;
	  while ($data = mysql_fetch_array($qry_berita)) {
	  $no++;
	  ?>
     
  
  <tr> 
    <td><? echo $data['id_fasilitas']; ?></td>
    <td><? echo $data['nama_Fasilitas'];?></td>
    <td width="18%"><a href="editfasilitas.php?id_fasilitas=<?php echo $data[id_fasilitas];?>" ><img src="edit.JPG" width="36" height="34"title="Edit"></a> 
<div align="center"></a> </td>
    <td width="18%"><a href="tampilfasilitas.php?do=hapus&id_fasilitas=<?php echo $data[id_fasilitas];?>"onClick='return Knf()'><img src="cancel.png"></td>
    </td>
  </tr>
  <?
      
       }
       
       ?>
  <tr> 
    <td colspan="4">HALAMAN
	<?php 
    			for($i=1;$i<=$jmlhal;$i++)
				if($i!=hal)
				{
				echo"<a href=$_SERVER[PHP_SELF]?tampilfasilitas.php&hal=$i>[ $i ]</a>  ";
				}
				else
				{
				echo"<b>$i</b>";
				}
			?>
  </td>
  </tr>
</table>

